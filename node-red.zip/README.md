# Node-RED

http://nodered.org

Low-code programming for event-driven applications.

![Node-RED: Low-code programming for event-driven applications.](http://nodered.org/images/node-red-screenshot.png)

## Quick Start

Check out http://nodered.org/docs/getting-started/ for full instructions on getting
started.

1. `yarn install`
2. `yarn start`
3. Open <http://localhost:8092>